﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using Quiz_Project.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Quiz_Project.Controllers
{
    public class HomeController : Controller
    {
        private readonly QuizExamenContext context;

        public HomeController(QuizExamenContext _context)
        {
            context = _context;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult NewQuiz()
        {

            return View();
        }
        [HttpPost]
        public IActionResult NewQuiz(string userName, string email, int facile, int moyen, int dificile)
        {
            Quiz quiz = new Quiz();
            quiz.UserName = userName;
            quiz.Email = email;

            context.Add<Quiz>(quiz);
            context.SaveChanges();

            int idQuiz = context.Quiz.OrderBy(quizN => quizN.QuizId).Last().QuizId;
            var questionFacile = context.Question.Where(q => q.CategoryId == 1).Take(facile).ToList();
            var questionMoyen = context.Question.Where(q => q.CategoryId == 2).Take(moyen).ToList();
            var questionDeficile = context.Question.Where(q => q.CategoryId == 3).Take(dificile).ToList();

            foreach (var item in questionFacile)
            {
                QuestionQuiz questionQuiz = new QuestionQuiz();

                questionQuiz.QuizId = idQuiz;
                questionQuiz.QuestionId = item.QuestionId;
                context.Add<QuestionQuiz>(questionQuiz);
                context.SaveChanges();
            }
            foreach (var item in questionMoyen)
            {
                QuestionQuiz questionQuiz = new QuestionQuiz();

                questionQuiz.QuizId = idQuiz;
                questionQuiz.QuestionId = item.QuestionId;
                context.Add<QuestionQuiz>(questionQuiz);
                context.SaveChanges();
            }
            foreach (var item in questionDeficile)
            {
                QuestionQuiz questionQuiz = new QuestionQuiz();

                questionQuiz.QuizId = idQuiz;
                questionQuiz.QuestionId = item.QuestionId;
                context.Add<QuestionQuiz>(questionQuiz);
                context.SaveChanges();
            }

            return RedirectToAction("Index");
        }


        public IActionResult PasserQuiz(string pattern)
        {

            if (pattern != null)
            {
                var quiz = context.Quiz.Where(q => q.UserName.StartsWith(pattern)).ToList();
                if (quiz.Count > 0)
                {
                    ViewBag.message = quiz.Count + ".Trouver ! Quiz de " + pattern;
                    ViewBag.style = "text-success";
                }
                else
                {
                    ViewBag.message = " Pas de resulta ! de quiz " + pattern;
                    ViewBag.style = "text-danger";
                }

                return View(quiz);
            }
            else
            {
                return View();
            }
            return View();

        }

        public IActionResult AnswerToQuiz(int id)
        {
            ViewBag.qzId = id;
            var QQ = context.QuestionQuiz.Where(q => q.QuizId == id);
            List<Question> listeQues = new List<Question>();
            foreach (var item in QQ.ToList())
            {
                var question = context.Question.Where(x => x.QuestionId == item.QuestionId).ToList();

                listeQues.Add(question[0]);
            }

            return View(listeQues);

        }
        public IActionResult Submit(int id)
        {
            foreach (var key in HttpContext.Request.Query.Keys)
            {
                Answer answer = new Answer();
                StringValues optionId;
                HttpContext.Request.Query.TryGetValue(key, out optionId);
                answer.OptionId = Int32.Parse(optionId);
                answer.QuizId = id;

                context.Add<Answer>(answer);
                context.SaveChanges();

            }

            return View("Index");
        }
        public IActionResult ReviserQuiz(int id)
        {
            ViewBag.qzId = id;
            var QQ = context.QuestionQuiz.Where(q => q.QuizId == id);
            List<Question> listeAnwer = new List<Question>();
            foreach (var item in QQ.ToList())
            {
                var question = context.Question.Where(x => x.QuestionId == item.QuestionId).ToList();

                listeAnwer.Add(question[0]);
            }

            return View(listeAnwer);

        }
        public IActionResult ReviewQuiz(string pattern) 
        {

            if (pattern != null)
            {
                var quiz = context.Quiz.Where(q => q.UserName.StartsWith(pattern)).ToList();
                if (quiz.Count > 0)
                {
                    ViewBag.message = quiz.Count + ".Trouver ! Quiz de " + pattern;
                    ViewBag.style = "text-success";
                }
                else
                {
                    ViewBag.message = " Pas de resulta ! de quiz " + pattern;
                    ViewBag.style = "text-danger";
                }

                return View(quiz);
            }
            else
            {
                return View();
            }
            return View();

        }

    }
}
